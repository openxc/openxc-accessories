/**
 * Provides common utilities such as data aging and file manipulation.
 */
package com.openxc.util;
